import com.moonwolf.local.Game;
import com.moonwolf.local.Json;
import java.util.*;
public class GameSmoke {
    static Map<String,Object> m(Object... xs){return Json.map(xs);}
    static String val(Map<String,Object> obj,String key){return Json.str(obj.get(key));}
    static void yes(boolean b,String msg){if(!b)throw new AssertionError(msg);}
    static Map<String,String> auth(Map<String,Object> user){return Map.of("room",val(user,"room"),"player",val(user,"player"),"token",val(user,"token"));}
    static Map<String,Object> request(Map<String,Object> user){return m("room",user.get("room"),"player",user.get("player"),"token",user.get("token"));}
    @SuppressWarnings("unchecked") static Map<String,Object> self(Game game,Map<String,Object> user){return (Map<String,Object>)game.view(auth(user)).get("private");}
    @SuppressWarnings("unchecked") static Map<String,Object> state(Game game,Map<String,Object> user){return game.view(auth(user));}
    @SuppressWarnings("unchecked") static List<Map<String,Object>> players(Map<String,Object> state){return (List<Map<String,Object>>)state.get("players");}
    static void tests(){
        Game g=new Game();Map<String,Object>[] members=new Map[4];members[0]=g.create(m("name","师姐"));
        for(int i=1;i<4;i++)members[i]=g.join(m("name","玩家"+i,"room",members[0].get("room")));
        yes(players(state(g,members[0])).size()==4,"all members joined");
        int[] wolfCounts=new int[4];
        for(int round=0;round<15;round++){
            Map<String,Object> started=request(members[0]);started.put("mode",round%2==0?"traditional":"phone");started.put("win","city");
            g.start(started);
            Set<String> found=new HashSet<>();int wolfIndex=-1;
            for(int i=0;i<4;i++){
                String role=val(self(g,members[i]),"role");found.add(role);
                if(role.equals("wolf")){wolfIndex=i;wolfCounts[i]++;}
                for(Map<String,Object> p:players(state(g,members[i])))yes(!p.containsKey("role"),"public role leaked");
            }
            yes(found.equals(Set.of("wolf","seer","guard","villager")),"incorrect role deal");
            while(val(state(g,members[0]),"phase").equals("night")){
                String stage=val(state(g,members[0]),"stage");
                int actor=-1;
                for(int i=0;i<4;i++)if(Json.bool(self(g,members[i]).get("canAct"))){actor=i;break;}
                yes(actor>=0,"stage without actors "+stage);
                Map<String,Object> act=request(members[actor]);act.put("target",members[wolfIndex].get("player"));g.action(act);
            }
            yes(val(state(g,members[0]),"phase").equals("day"),"night ended too early");
            Map<String,Object> begin=request(members[0]);g.beginVote(begin);
            // Everyone still alive votes for the wolf.
            for(int i=0;i<4;i++){
                if(!Json.bool(self(g,members[i]).get("alive")))continue;
                Map<String,Object> vote=request(members[i]);vote.put("target",members[wolfIndex].get("player"));g.vote(vote);
            }
            Map<String,Object> end=state(g,members[0]);yes(val(end,"phase").equals("ended"),"winner was not decided");
            for(int i=0;i<4;i++){
                Map<String,Object> personal=state(g,members[i]);
                List<Object> hist=(List<Object>)personal.get("history");
                yes(hist.size()==1,"vote results not on all phones");
                Map<String,Object> record=(Map<String,Object>)hist.get(0);
                List<Object> ballots=(List<Object>)record.get("ballots");
                yes(!ballots.isEmpty(),"missing who-voted-for-whom");
            }
        }
        int distinct=0;for(int n:wolfCounts)if(n>0)distinct++;
        yes(distinct>=2,"random deal stuck on same player");
        System.out.println("PASS: 4 players; 15 fresh secure shuffles; roles private; day/night; per-voter ballots; no rejoin between rounds; different modes.");
    }
    public static void main(String[] args){tests();}
}
