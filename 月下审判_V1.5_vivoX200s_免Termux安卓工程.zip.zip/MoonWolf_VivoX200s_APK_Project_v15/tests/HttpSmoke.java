import com.moonwolf.local.LocalServer;
import java.nio.file.*;
import java.net.*;
import java.io.*;
public class HttpSmoke {
 public static void main(String[] args)throws Exception{
  LocalServer server=new LocalServer(Files.readAllBytes(Path.of(args[0])),Files.readAllBytes(Path.of(args[1])));server.start();
  try{
   URL url=new URL("http://127.0.0.1:3000/api/health");HttpURLConnection c=(HttpURLConnection)url.openConnection();
   String res=new String(c.getInputStream().readAllBytes());if(!res.contains("MoonWolf Android Local"))throw new IllegalStateException("Health response: "+res);
   if(!new String(new URL("http://127.0.0.1:3000/").openStream().readAllBytes()).contains("月下审判"))throw new IllegalStateException("homepage unavailable");
   System.out.println("PASS: LocalServer self-hosted HTTP health and web assets");
  }finally{server.stop();}
 }
}
