#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p /tmp/moonwolf-v15-classes
javac -encoding UTF-8 -d /tmp/moonwolf-v15-classes app/src/main/java/com/moonwolf/local/{Json,Game,LocalServer}.java tests/{GameSmoke,HttpSmoke}.java
java -cp /tmp/moonwolf-v15-classes GameSmoke
java -cp /tmp/moonwolf-v15-classes HttpSmoke app/src/main/assets/index.html app/src/main/assets/qrcode.js
node --check app/src/main/assets/qrcode.js
printf '\nAll local JVM and syntax tests succeeded.\n'
