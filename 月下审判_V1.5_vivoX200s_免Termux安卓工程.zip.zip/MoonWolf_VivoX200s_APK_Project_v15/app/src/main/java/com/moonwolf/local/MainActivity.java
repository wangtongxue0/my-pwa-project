package com.moonwolf.local;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.os.*;
import android.speech.tts.TextToSpeech;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.util.Locale;

/** Host app: one APK runs HTTP server and displays the same game page as guests. */
public class MainActivity extends Activity {
    private TextView status,help;
    private WebView web;
    private TextToSpeech tts;
    private volatile boolean speechReady=false;
    private final Handler main=new Handler(Looper.getMainLooper());
    private boolean webLoaded=false;
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    @Override protected void onCreate(Bundle savedInstanceState){super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(12,23,36));getWindow().setNavigationBarColor(Color.rgb(12,23,36));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(13,23,36));
        LinearLayout toolbar=new LinearLayout(this);toolbar.setPadding(dp(10),dp(12),dp(10),dp(8));toolbar.setOrientation(LinearLayout.VERTICAL);
        status=text("🐺 月下审判 · 本地联机服务器未启动",15,Color.WHITE);toolbar.addView(status);
        help=text("先开个人热点，再启动服务；其它手机连热点后扫码加入。",12,Color.rgb(189,205,219));toolbar.addView(help);
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
        Button hotspot=button("① 热点设置");hotspot.setOnClickListener(v->openHotspot());actions.addView(hotspot,new LinearLayout.LayoutParams(0,dp(48),1));
        Button begin=button("② 启动游戏");begin.setOnClickListener(v->startServer());actions.addView(begin,new LinearLayout.LayoutParams(0,dp(48),1));
        Button stop=button("停止");stop.setOnClickListener(v->stopServer());actions.addView(stop,new LinearLayout.LayoutParams(dp(65),dp(48)));
        toolbar.addView(actions);root.addView(toolbar);
        web=new WebView(this);web.setBackgroundColor(Color.rgb(13,23,36));web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(false);
        web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient(){@Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error){
            if(request.isForMainFrame())status.setText("服务器未连接，请重新点击启动游戏");}});
        web.addJavascriptInterface(new SpeakBridge(),"MoonWolfNative");
        root.addView(web,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
        tts=new TextToSpeech(this, code->{speechReady=code==TextToSpeech.SUCCESS;if(speechReady)tts.setLanguage(Locale.SIMPLIFIED_CHINESE);});
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},101);
        }
        main.postDelayed(()->{if(GameService.isRunning())displayGame();},350);
    }
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(12);return b;}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private void openHotspot(){
        try{startActivity(new Intent("android.settings.TETHER_SETTINGS"));}
        catch(Exception e){try{startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));}catch(Exception other){Toast.makeText(this,"请在手机设置中手动开启个人热点",Toast.LENGTH_LONG).show();}}
    }
    private void startServer(){
        if(!GameService.isRunning()){
            Intent intent=new Intent(this,GameService.class);
            try{if(Build.VERSION.SDK_INT>=26)startForegroundService(intent);else startService(intent);}
            catch(Exception e){status.setText("启动失败："+e.getMessage());return;}
        }
        status.setText("正在启动本地联机服务……");
        retryLoad(0);
    }
    private void retryLoad(int attempt){main.postDelayed(()->{
        if(GameService.isRunning())displayGame();
        else if(attempt<15)retryLoad(attempt+1);
        else status.setText("启动失败："+GameService.error());
    },200);}
    private void displayGame(){
        status.setText("🟢 游戏服务已启动 · 房主可以创建游戏");
        java.util.List<String> ips=LocalServer.addresses();
        help.setText(ips.isEmpty()?"其他玩家连房主热点；可在游戏邀请面板修改热点地址。":"手机热点可能使用："+ips.get(0)+":3000（请核对连接热点设备的网关）");
        if(!webLoaded){webLoaded=true;web.loadUrl("http://127.0.0.1:3000/");}
    }
    private void stopServer(){new AlertDialog.Builder(this).setTitle("结束本地服务器？")
        .setMessage("所有玩家将断开连接，本次对局数据会丢失。")
        .setNegativeButton("取消",null).setPositiveButton("停止",(dialog,which)->{
            stopService(new Intent(this,GameService.class));webLoaded=false;web.loadUrl("about:blank");
            status.setText("服务器已停止");help.setText("点击启动游戏可创建新房间");
        }).show();}
    public class SpeakBridge {
        @JavascriptInterface public void speak(String words){if(words==null||words.length()>350)return;
            main.post(()->{if(tts!=null&&speechReady)tts.speak(words,TextToSpeech.QUEUE_FLUSH,null,"moonwolf_announce");});}
        @JavascriptInterface public void stopSpeak(){main.post(()->{if(tts!=null)tts.stop();});}
    }
    @Override public void onBackPressed(){if(web.canGoBack()){web.goBack();}else new AlertDialog.Builder(this)
        .setMessage("退出当前画面？本地联机服务仍会运行。")
        .setNegativeButton("取消",null).setPositiveButton("退出界面",(a,b)->finish()).show();}
    @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}if(web!=null){web.destroy();}super.onDestroy();}
}
