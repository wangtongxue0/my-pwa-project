package com.moonwolf.local;

import java.security.SecureRandom;
import java.util.*;

/** Thread-safe room authority. Only this class deals identities and win conditions. */
public final class Game {
    public static final int MAX_PLAYERS = 30;
    private static final String[] NIGHT_ORDER = {"guard", "wolf", "seer", "witch"};
    private static final Map<String,String> NAMES = new LinkedHashMap<>();
    static { NAMES.put("wolf","狼人"); NAMES.put("seer","预言家"); NAMES.put("guard","守卫"); NAMES.put("witch","女巫"); NAMES.put("villager","村民"); }
    private final SecureRandom rng = new SecureRandom();
    private final Map<String,Room> rooms = new HashMap<>();
    private static final class Player {
        String id,secret,name,role="";int seat;boolean alive=true;
        Player(String id,String secret,String name,int seat){this.id=id;this.secret=secret;this.name=name;this.seat=seat;}
    }
    private static final class Room {
        String code,host,phase="lobby",stage="",mode="traditional",win="city",announcement="等待玩家进入房间",winner="",wolfTarget="",guarded="",poison="";
        int day=0,round=0,announcementId=1;boolean saved=false,saveUsed=false,poisonUsed=false;
        Map<String,Integer> roles=new LinkedHashMap<>();
        List<Player> players=new ArrayList<>();
        Map<String,Object> actions=new HashMap<>();
        Map<String,String> inspections=new HashMap<>();
        List<Object> history=new ArrayList<>();
        List<Object> wolfChat=new ArrayList<>();
    }
    public static class GameError extends RuntimeException { public GameError(String s){super(s);} }
    private static void require(boolean ok,String msg){if(!ok)throw new GameError(msg);}
    private String secret(){byte[] a=new byte[18];rng.nextBytes(a);return Base64.getUrlEncoder().withoutPadding().encodeToString(a);}
    private String cleanName(Object x){String name=Json.str(x).trim();require(name.length()>0 && name.length()<=16,"昵称需要1～16个字符");return name;}
    private Room room(Object id){Room r=rooms.get(Json.str(id));require(r!=null,"房间不存在或房主已关闭服务");return r;}
    private Player player(Room r,Object id,Object secret){for(Player p:r.players)if(p.id.equals(Json.str(id))&&p.secret.equals(Json.str(secret)))return p;throw new GameError("身份验证失败，请重新进入房间");}
    private void host(Room r,Player p){require(r.host.equals(p.id),"只有房主可以执行此操作");}
    private void say(Room r,String text){r.announcement=text;r.announcementId++;}
    private Player find(Room r,Object id){for(Player p:r.players)if(p.id.equals(Json.str(id)))return p;return null;}
    private List<Player> alive(Room r){List<Player> out=new ArrayList<>();for(Player p:r.players)if(p.alive)out.add(p);return out;}
    private String label(Player p){return p==null?"弃票":p.seat+"号 "+p.name;}
    private boolean wolf(Player p){return "wolf".equals(p.role);}
    private boolean god(Player p){return !wolf(p)&&!"villager".equals(p.role);}
    private Map<String,Integer> defaultRoles(){Map<String,Integer> a=new LinkedHashMap<>();a.put("wolf",1);a.put("seer",1);a.put("guard",1);a.put("witch",0);a.put("villager",1);return a;}
    public synchronized Map<String,Object> create(Map<String,Object> args){
        String name=cleanName(args.get("name"));String code;do {code=String.valueOf(100000+rng.nextInt(900000));}while(rooms.containsKey(code));
        Room r=new Room();r.code=code;r.roles=defaultRoles();rooms.put(code,r);
        Player p=new Player(secret(),secret(),name,1);r.players.add(p);r.host=p.id;
        return Json.map("room",code,"player",p.id,"token",p.secret);
    }
    public synchronized Map<String,Object> join(Map<String,Object> args){
        Room r=room(args.get("room"));require("lobby".equals(r.phase),"本局已经开始，请下一局再加入");
        require(r.players.size()<MAX_PLAYERS,"房间人数已满");
        String name=cleanName(args.get("name"));for(Player p:r.players)require(!p.name.equals(name),"昵称已被使用，请换一个");
        Player p=new Player(secret(),secret(),name,r.players.size()+1);r.players.add(p);
        return Json.map("room",r.code,"player",p.id,"token",p.secret);
    }
    private Map<String,Integer> validateRoles(Object raw){Map<String,Object> m=Json.obj(raw);Map<String,Integer> roles=new LinkedHashMap<>();int total=0,w=0;
        for(String key:NAMES.keySet()){int n=Json.num(m.get(key),0);require(n>=0&&n<=MAX_PLAYERS,"身份数量不合法");roles.put(key,n);total+=n;if(key.equals("wolf"))w=n;}
        require(total>=2&&total<=MAX_PLAYERS,"角色总人数必须为2～30人");
        require(w>=1&&w<total,"至少需要1名狼人和1名好人");return roles;
    }
    public synchronized Map<String,Object> start(Map<String,Object> a){
        Room r=room(a.get("room"));Player p=player(r,a.get("player"),a.get("token"));host(r,p);
        require("lobby".equals(r.phase)||"ended".equals(r.phase)||"results".equals(r.phase),"请等待当前回合结束");
        Map<String,Integer> roles=a.containsKey("roles")?validateRoles(a.get("roles")):r.roles;
        int total=0;for(int n:roles.values())total+=n;
        require(r.players.size()==total,"当前有"+r.players.size()+"人，身份牌总数"+total+"张，请保持一致");
        String mode=Json.str(a.get("mode"));require(mode.equals("traditional")||mode.equals("phone"),"请选择游戏模式");
        String win=Json.str(a.get("win"));require(win.equals("city")||win.equals("side"),"请选择胜利规则");
        r.mode=mode;r.win=win;r.roles=roles;r.round++;r.day=0;r.winner="";r.history.clear();r.inspections.clear();r.saveUsed=false;r.poisonUsed=false;
        List<String> cards=new ArrayList<>();for(Map.Entry<String,Integer> entry:roles.entrySet())for(int i=0;i<entry.getValue();i++)cards.add(entry.getKey());
        for(int i=cards.size()-1;i>0;i--){int j=rng.nextInt(i+1);Collections.swap(cards,i,j);}
        for(int i=0;i<r.players.size();i++){Player x=r.players.get(i);x.role=cards.get(i);x.alive=true;}
        nextNight(r);
        return Json.map("ok",true,"round",r.round);
    }
    private void nextNight(Room r){
        r.day++;r.phase="night";r.stage="";r.wolfChat.clear();r.actions.clear();r.wolfTarget="";r.guarded="";r.poison="";r.saved=false;
        nextStage(r);
    }
    private List<Player> stageActors(Room r){List<Player> ret=new ArrayList<>();if(!"night".equals(r.phase))return ret;
        for(Player p:alive(r)){if(r.stage.equals(p.role)||(r.stage.equals("wolf")&&wolf(p)))ret.add(p);}return ret;
    }
    private void nextStage(Room r){
        r.actions.clear();int i=Arrays.asList(NIGHT_ORDER).indexOf(r.stage)+1;
        while(i<NIGHT_ORDER.length){String next=NIGHT_ORDER[i++];boolean exists=false;for(Player p:alive(r))if(next.equals(p.role)){exists=true;break;}
            if(exists){r.stage=next;String speech;
                switch(next){case "guard":speech="守卫请睁眼，请选择今晚守护的玩家。";break;
                    case "wolf":speech="狼人请睁眼，请选择今晚击杀的玩家。";break;
                    case "seer":speech="预言家请睁眼，请选择今晚查验的玩家。";break;
                    default:speech="女巫请睁眼，决定是否使用解药和毒药。";}
                say(r,"第"+r.day+"夜，天黑请闭眼。"+speech);return;}
        }
        finishNight(r);
    }
    private void saveAction(Room r){
        if(r.stage.equals("guard")) { for(Object value:r.actions.values())r.guarded=Json.str(value); }
        else if(r.stage.equals("wolf")){
            Map<String,Integer> votes=new LinkedHashMap<>();for(Object value:r.actions.values()){String id=Json.str(value);if(!id.isEmpty())votes.put(id,votes.getOrDefault(id,0)+1);}
            int best=0,count=0;String selected="";for(Map.Entry<String,Integer> v:votes.entrySet()){if(v.getValue()>best){best=v.getValue();count=1;selected=v.getKey();}else if(v.getValue()==best)count++;}
            r.wolfTarget=count==1?selected:"";
        }
        else if(r.stage.equals("seer")){
            for(Map.Entry<String,Object> entry:r.actions.entrySet()){Player target=find(r,entry.getValue());r.inspections.put(entry.getKey(),target==null?"放弃查验":label(target)+"："+(wolf(target)?"狼人":"好人"));}
        }
        else if(r.stage.equals("witch")){
            for(Object value:r.actions.values()){
                Map<String,Object> action=Json.obj(value);
                if(Json.bool(action.get("save"))&&!r.saveUsed&&!r.wolfTarget.isEmpty()){r.saveUsed=true;r.saved=true;}
                String target=Json.str(action.get("poison"));if(!target.isEmpty()&&!r.poisonUsed){r.poisonUsed=true;r.poison=target;}
            }
        }
        nextStage(r);
    }
    private void finishNight(Room r){
        List<String> deaths=new ArrayList<>();if(!r.wolfTarget.isEmpty()&&!r.wolfTarget.equals(r.guarded)&&!r.saved)deaths.add(r.wolfTarget);
        if(!r.poison.isEmpty()&&!deaths.contains(r.poison))deaths.add(r.poison);
        List<String> names=new ArrayList<>();for(String id:deaths){Player p=find(r,id);if(p!=null&&p.alive){p.alive=false;names.add(label(p));}}
        r.phase="day";r.stage="";r.actions.clear();
        say(r,names.isEmpty()?"天亮了，昨晚是平安夜。请开始白天讨论。":"天亮了，昨晚出局的玩家是："+String.join("、",names)+"。请开始白天讨论。");checkWin(r);
    }
    private void checkWin(Room r){
        if("lobby".equals(r.phase)||"ended".equals(r.phase))return;
        int wolves=0,good=0,gods=0,villagers=0;
        for(Player p:alive(r)){if(wolf(p))wolves++;else{good++;if(god(p))gods++;else villagers++;}}
        String winner="";if(wolves==0)winner="好人阵营";
        else if("city".equals(r.win)&&good==0)winner="狼人阵营";
        else if("side".equals(r.win)&&(gods==0||villagers==0))winner="狼人阵营";
        if(!winner.isEmpty()){r.winner=winner;r.phase="ended";r.stage="";say(r,winner+"获胜！本局结束。房主可以保留所有人，重新随机发牌。");}
    }
    public synchronized Map<String,Object> action(Map<String,Object> a){
        Room r=room(a.get("room"));Player p=player(r,a.get("player"),a.get("token"));
        require("night".equals(r.phase)&&p.alive,"当前不是你的夜间行动阶段");
        require(stageActors(r).contains(p),"当前不是你的身份行动回合");require(!r.actions.containsKey(p.id),"本回合已经行动，请等待其他玩家");
        Object target=a.get("target");
        if("witch".equals(r.stage)){
            boolean save=Json.bool(a.get("save"));String poison=Json.str(a.get("poison"));
            require(!save||(!r.saveUsed&&!r.wolfTarget.isEmpty()),"解药无法使用");
            require(poison.isEmpty()||(!r.poisonUsed&&find(r,poison)!=null&&find(r,poison).alive),"毒药目标无效或已经用完");
            require(!(save&&!poison.isEmpty()),"测试版不支持同夜同时使用两瓶药");
            r.actions.put(p.id,Json.map("save",save,"poison",poison));
        }else{
            String id=Json.str(target);require(id.isEmpty()||find(r,id)!=null&&find(r,id).alive,"请选择仍然存活的玩家");
            r.actions.put(p.id,id);
        }
        if(r.actions.size()==stageActors(r).size())saveAction(r);
        return Json.map("ok",true);
    }
    public synchronized Map<String,Object> chat(Map<String,Object> a){
        Room r=room(a.get("room"));Player p=player(r,a.get("player"),a.get("token"));
        require(r.mode.equals("phone")&&r.phase.equals("night")&&r.stage.equals("wolf")&&p.alive&&wolf(p),"当前不能发送狼人消息");
        String message=Json.str(a.get("text")).trim();require(!message.isEmpty()&&message.length()<=100,"每条狼人消息需要1～100字");
        r.wolfChat.add(Json.map("seat",p.seat,"name",p.name,"text",message));
        if(r.wolfChat.size()>30)r.wolfChat.remove(0);
        return Json.map("ok",true);
    }
    public synchronized Map<String,Object> beginVote(Map<String,Object> a){
        Room r=room(a.get("room"));Player p=player(r,a.get("player"),a.get("token"));host(r,p);
        require("day".equals(r.phase),"请等到白天讨论阶段");r.phase="vote";r.actions.clear();say(r,"白天讨论结束，现在开始放逐投票。请所有存活玩家通过手机投票。");return Json.map("ok",true);
    }
    public synchronized Map<String,Object> vote(Map<String,Object> a){
        Room r=room(a.get("room"));Player p=player(r,a.get("player"),a.get("token"));
        require("vote".equals(r.phase)&&p.alive,"当前不能投票");require(!r.actions.containsKey(p.id),"你已经投过票了");
        String id=Json.str(a.get("target"));require(id.isEmpty()||find(r,id)!=null&&find(r,id).alive,"候选玩家无效");r.actions.put(p.id,id);
        if(r.actions.size()==alive(r).size())settleVote(r);
        return Json.map("ok",true);
    }
    private void settleVote(Room r){
        Map<String,Integer> counts=new LinkedHashMap<>();List<Object> ballots=new ArrayList<>();
        for(Player voter:alive(r)){
            String target=Json.str(r.actions.get(voter.id));Player chosen=find(r,target);
            ballots.add(Json.map("voterSeat",voter.seat,"voter",voter.name,"targetSeat",chosen==null?0:chosen.seat,"target",chosen==null?"弃票":chosen.name));
            if(chosen!=null)counts.put(target,counts.getOrDefault(target,0)+1);
        }
        int top=0,ties=0;String selected="";
        for(Map.Entry<String,Integer> e:counts.entrySet()){if(e.getValue()>top){top=e.getValue();ties=1;selected=e.getKey();}else if(e.getValue()==top)ties++;}
        Player exiled=ties==1?find(r,selected):null;
        Map<String,Object> result=Json.map("day",r.day,"ballots",ballots,"exiled",exiled==null?"平票／无人出局":label(exiled));
        r.history.add(result);r.phase="results";r.actions.clear();
        if(exiled!=null){exiled.alive=false;say(r,"投票结束，"+label(exiled)+"被放逐。所有玩家现在可以查看完整票型。");}
        else say(r,"投票结束，本轮平票或全部弃票，无人出局。所有玩家现在可以查看完整票型。");
        checkWin(r);
    }
    public synchronized Map<String,Object> next(Map<String,Object> a){
        Room r=room(a.get("room"));Player p=player(r,a.get("player"),a.get("token"));host(r,p);
        require("results".equals(r.phase),"当前无法进入下一夜");nextNight(r);return Json.map("ok",true);
    }
    public synchronized Map<String,Object> view(Map<String,String> q){
        Room r=room(q.get("room"));Player me=player(r,q.get("player"),q.get("token"));
        List<Object> publicPlayers=new ArrayList<>();for(Player p:r.players){Map<String,Object> basic=Json.map("id",p.id,"seat",p.seat,"name",p.name,"alive",p.alive);
            if("ended".equals(r.phase))basic.put("role",p.role);publicPlayers.add(basic);}
        boolean canAct="night".equals(r.phase)&&stageActors(r).contains(me)&&!r.actions.containsKey(me.id);
        List<Object> mates=new ArrayList<>();if(!"lobby".equals(r.phase)&&wolf(me))for(Player p:r.players)if(wolf(p)&&!p.id.equals(me.id))mates.add(Json.map("seat",p.seat,"name",p.name));
        Map<String,Object> privateInfo=Json.map("id",me.id,"seat",me.seat,"host",r.host.equals(me.id),"role","lobby".equals(r.phase)?"":me.role,
            "roleName", "lobby".equals(r.phase)?"":NAMES.get(me.role),"alive",me.alive,"mates",mates,"canAct",canAct,
            "actionDone",r.actions.containsKey(me.id),"inspection",r.inspections.getOrDefault(me.id,""),
            "wolfTarget",me.role.equals("witch")&&r.stage.equals("witch")?r.wolfTarget:"", "saveUsed",r.saveUsed,"poisonUsed",r.poisonUsed,
            "wolfChat",wolf(me)&&r.mode.equals("phone")?new ArrayList<>(r.wolfChat):new ArrayList<>());
        return Json.map("ok",true,"room",r.code,"phase",r.phase,"stage",r.stage,"mode",r.mode,"win",r.win,
            "round",r.round,"day",r.day,"winner",r.winner,"announcement",r.announcement,"announcementId",r.announcementId,
            "players",publicPlayers,"roles",r.roles,"private",privateInfo,"stageCount",r.actions.size(),"stageTotal",stageActors(r).size(),
            "voteCount","vote".equals(r.phase)?r.actions.size():0,"voteTotal",alive(r).size(),"history",r.history);
    }
    public synchronized Map<String,Object> api(String method,Map<String,Object> data,Map<String,String> query){
        switch(method){case "create":return create(data);case "join":return join(data);case "start":return start(data);case "action":return action(data);
            case "vote":return vote(data);case "chat":return chat(data);case "begin-vote":return beginVote(data);case "next":return next(data);case "state":return view(query);
            default:throw new GameError("未知操作");}
    }
}
