package com.moonwolf.local;

import android.app.*;
import android.content.*;
import android.os.*;
import java.io.*;

/** Foreground service keeps the room alive when the host opens hotspot settings. */
public class GameService extends Service {
    private static final String CHANNEL="moonwolf_local_game";
    private static volatile boolean running=false;
    private static volatile String lastError="";
    private LocalServer server;
    public static boolean isRunning(){return running;}
    public static String error(){return lastError;}
    @Override public void onCreate(){super.onCreate();
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel channel=new NotificationChannel(CHANNEL,"月下审判本地联机",NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("游戏中保持本地联机服务运行");nm.createNotificationChannel(channel);
        Intent launch=new Intent(this,MainActivity.class);launch.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent intent=PendingIntent.getActivity(this,0,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification notification=new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("月下审判正在运行").setContentText("其他玩家可连接房主热点并加入游戏")
            .setOngoing(true).setContentIntent(intent).build();
        startForeground(42,notification);
        try {
            server=new LocalServer(read("index.html"),read("qrcode.js"));server.start();running=true;lastError="";
        } catch(Exception e){running=false;lastError=e.getClass().getSimpleName()+": "+e.getMessage();stopSelf();}
    }
    private byte[] read(String filename)throws IOException {try(InputStream in=getAssets().open(filename);ByteArrayOutputStream out=new ByteArrayOutputStream()){
        byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);return out.toByteArray();}}
    @Override public int onStartCommand(Intent intent,int flags,int startId){return START_STICKY;}
    @Override public void onDestroy(){running=false;if(server!=null)server.stop();super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
