package com.moonwolf.local;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

/** Embedded HTTP server. Uses only Java/Android platform APIs; no Termux or Node.js. */
public final class LocalServer {
    public static final int PORT=3000;
    private final Game game=new Game();
    private final byte[] home,qr;
    private final ExecutorService pool=Executors.newFixedThreadPool(12);
    private ServerSocket server;
    private volatile boolean running;

    public LocalServer(byte[] home,byte[] qr){this.home=home;this.qr=qr;}
    public synchronized void start() throws IOException {
        if(running)return;
        ServerSocket socket=new ServerSocket();socket.setReuseAddress(true);
        socket.bind(new InetSocketAddress("0.0.0.0",PORT),50);
        this.server=socket;running=true;
        Thread t=new Thread(()->{while(running){try{Socket c=socket.accept();pool.execute(()->handle(c));}catch(IOException e){if(running)e.printStackTrace();break;}catch(RejectedExecutionException e){break;}}},"MoonWolf HTTP acceptor");
        t.setDaemon(true);t.start();
    }
    public synchronized void stop(){running=false;try{if(server!=null)server.close();}catch(IOException ignored){}pool.shutdownNow();}
    public boolean isRunning(){return running;}
    public static List<String> addresses(){
        LinkedHashSet<String> all=new LinkedHashSet<>();
        try{Enumeration<NetworkInterface> interfaces=NetworkInterface.getNetworkInterfaces();while(interfaces.hasMoreElements()){
            NetworkInterface net=interfaces.nextElement();if(net.isLoopback()||!net.isUp())continue;
            Enumeration<InetAddress> addrs=net.getInetAddresses();while(addrs.hasMoreElements()){
                InetAddress address=addrs.nextElement();if(!(address instanceof Inet4Address)||address.isLoopbackAddress())continue;
                String ip=address.getHostAddress();if(address.isSiteLocalAddress())all.add(ip);
            }
        }}catch(Exception ignored){}
        List<String> out=new ArrayList<>(all);
        out.sort((a,b)->Integer.compare(priority(a),priority(b)));return out;
    }
    private static int priority(String ip){if(ip.startsWith("192.168."))return 0;if(ip.startsWith("172."))return 1;if(ip.startsWith("10."))return 2;return 3;}
    private static String readLine(InputStream stream,int max) throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream();int ch;
        while((ch=stream.read())!=-1){if(ch=='\n')break;if(ch!='\r')out.write(ch);if(out.size()>max)throw new IOException("Request line too long");}
        if(ch==-1&&out.size()==0)return null;return out.toString("UTF-8");
    }
    private static Map<String,String> parseQuery(String url){Map<String,String> m=new HashMap<>();int k=url.indexOf('?');if(k<0)return m;
        for(String item:url.substring(k+1).split("&")){int eq=item.indexOf('=');String key=eq>=0?item.substring(0,eq):item;String value=eq>=0?item.substring(eq+1):"";
            try{m.put(URLDecoder.decode(key,"UTF-8"),URLDecoder.decode(value,"UTF-8"));}catch(Exception ignored){}
        }return m;
    }
    private void handle(Socket socket){try(Socket c=socket){c.setSoTimeout(10000);InputStream in=new BufferedInputStream(c.getInputStream());OutputStream out=new BufferedOutputStream(c.getOutputStream());
        String req=readLine(in,4096);if(req==null)return;String[] parts=req.split(" ");if(parts.length<2){write(out,400,"application/json",Json.write(Json.map("error","请求格式错误")).getBytes(StandardCharsets.UTF_8));return;}
        String method=parts[0],url=parts[1],path=url.split("\\?",2)[0];int length=0;
        for(int i=0;i<70;i++){String header=readLine(in,8192);if(header==null||header.isEmpty())break;int colon=header.indexOf(':');if(colon>0&&header.substring(0,colon).trim().equalsIgnoreCase("Content-Length"))length=Integer.parseInt(header.substring(colon+1).trim());}
        if(length<0||length>32768){write(out,413,"application/json",Json.write(Json.map("error","请求数据过大")).getBytes(StandardCharsets.UTF_8));return;}
        if(method.equals("GET")&&(path.equals("/")||path.equals("/index.html"))){write(out,200,"text/html; charset=utf-8",home);return;}
        if(method.equals("GET")&&path.equals("/qrcode.js")){write(out,200,"application/javascript; charset=utf-8",qr);return;}
        if(method.equals("GET")&&path.equals("/api/health")){writeJSON(out,200,Json.map("ok",true,"app","MoonWolf Android Local","version","1.5"));return;}
        if(method.equals("GET")&&path.equals("/api/addresses")){writeJSON(out,200,Json.map("ok",true,"addresses",addresses()));return;}
        if(path.startsWith("/api/")){
            Map<String,Object> args=new LinkedHashMap<>();
            if(method.equals("POST")){
                byte[] data=new byte[length];int off=0;while(off<length){int n=in.read(data,off,length-off);if(n<0)throw new EOFException();off+=n;}
                args=Json.obj(Json.parse(new String(data,StandardCharsets.UTF_8)));
            }
            try{Map<String,Object> result=game.api(path.substring(5),args,parseQuery(url));writeJSON(out,200,result);}
            catch(Game.GameError e){writeJSON(out,400,Json.map("ok",false,"error",e.getMessage()));}
            catch(IllegalArgumentException e){writeJSON(out,400,Json.map("ok",false,"error","请求内容格式错误"));}
            return;
        }
        writeJSON(out,404,Json.map("ok",false,"error","页面不存在"));
    }catch(Exception e){/* A disconnected browser must not stop the room. */}}
    private static void writeJSON(OutputStream out,int status,Object data)throws IOException{write(out,status,"application/json; charset=utf-8",Json.write(data).getBytes(StandardCharsets.UTF_8));}
    private static void write(OutputStream out,int status,String type,byte[] bytes)throws IOException{
        String message=status==200?"OK":status==400?"Bad Request":status==404?"Not Found":"Request Error";
        String head="HTTP/1.1 "+status+" "+message+"\r\nContent-Type: "+type+"\r\nContent-Length: "+bytes.length+"\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n";
        out.write(head.getBytes(StandardCharsets.US_ASCII));out.write(bytes);out.flush();
    }
}
