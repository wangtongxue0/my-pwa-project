package com.moonwolf.local;

import java.util.*;

/** Small dependency-free JSON reader/writer for the local HTTP protocol. */
public final class Json {
    private Json() {}
    public static Object parse(String src) { Parser p = new Parser(src); Object o=p.value(); p.white(); if(p.pos!=src.length())throw new IllegalArgumentException("JSON trailing data"); return o; }
    @SuppressWarnings("unchecked") public static Map<String,Object> obj(Object x) { return x instanceof Map ? (Map<String,Object>)x : new LinkedHashMap<>(); }
    public static String str(Object x) { return x==null?"":String.valueOf(x); }
    public static int num(Object x,int fallback) {if(x instanceof Number)return ((Number)x).intValue();try{return Integer.parseInt(str(x));}catch(Exception e){return fallback;}}
    public static boolean bool(Object x) { return Boolean.TRUE.equals(x); }
    public static Map<String,Object> map(Object...args) { Map<String,Object> o=new LinkedHashMap<>();for(int i=0;i+1<args.length;i+=2)o.put(String.valueOf(args[i]),args[i+1]);return o; }
    public static String write(Object x) {StringBuilder b=new StringBuilder();emit(b,x);return b.toString();}
    private static void emit(StringBuilder b,Object x) {
        if(x==null){b.append("null");return;}
        if(x instanceof Boolean || x instanceof Number){b.append(x);return;}
        if(x instanceof Map){b.append('{');boolean f=true;for(Object entry0:((Map<?,?>)x).entrySet()){Map.Entry<?,?> entry=(Map.Entry<?,?>)entry0;if(!f)b.append(',');f=false;emit(b,String.valueOf(entry.getKey()));b.append(':');emit(b,entry.getValue());}b.append('}');return;}
        if(x instanceof Collection){b.append('[');boolean f=true;for(Object o:(Collection<?>)x){if(!f)b.append(',');f=false;emit(b,o);}b.append(']');return;}
        b.append('"');for(char c:String.valueOf(x).toCharArray()){switch(c){case '"':b.append("\\\"");break;case '\\':b.append("\\\\");break;case '\n':b.append("\\n");break;case '\r':b.append("\\r");break;case '\t':b.append("\\t");break;default:if(c<32)b.append(String.format(Locale.ROOT,"\\u%04x",(int)c));else b.append(c);}}b.append('"');
    }
    private static class Parser {
        final String s;int pos;
        Parser(String text){s=text;}
        void white(){while(pos<s.length()&&Character.isWhitespace(s.charAt(pos)))pos++;}
        char peek(){white();return pos<s.length()?s.charAt(pos):'\0';}
        void eat(char c){white();if(pos>=s.length()||s.charAt(pos)!=c)throw new IllegalArgumentException("Invalid JSON at "+pos);pos++;}
        Object value(){char c=peek();if(c=='"')return string();if(c=='{')return object();if(c=='[')return array();if(c=='t'&&s.startsWith("true",pos)){pos+=4;return true;}if(c=='f'&&s.startsWith("false",pos)){pos+=5;return false;}if(c=='n'&&s.startsWith("null",pos)){pos+=4;return null;}return number();}
        String string(){eat('"');StringBuilder b=new StringBuilder();while(pos<s.length()){char c=s.charAt(pos++);if(c=='"')return b.toString();if(c=='\\'){if(pos==s.length())break;char a=s.charAt(pos++);switch(a){case '"':b.append('"');break;case '\\':b.append('\\');break;case '/':b.append('/');break;case 'n':b.append('\n');break;case 'r':b.append('\r');break;case 't':b.append('\t');break;case 'b':b.append('\b');break;case 'f':b.append('\f');break;case 'u':if(pos+4>s.length())throw new IllegalArgumentException("Invalid unicode escape");b.append((char)Integer.parseInt(s.substring(pos,pos+4),16));pos+=4;break;default:throw new IllegalArgumentException("Invalid escape");}}else b.append(c);}throw new IllegalArgumentException("Unterminated string");}
        Object number(){white();int start=pos;while(pos<s.length()&&"-+0123456789.eE".indexOf(s.charAt(pos))>=0)pos++;if(pos==start)throw new IllegalArgumentException("Invalid JSON at "+pos);String n=s.substring(start,pos);try{if(n.contains(".")||n.contains("e")||n.contains("E"))return Double.parseDouble(n);return Long.parseLong(n);}catch(NumberFormatException e){throw new IllegalArgumentException("Invalid number");}}
        Map<String,Object> object(){eat('{');Map<String,Object> result=new LinkedHashMap<>();if(peek()=='}'){pos++;return result;}while(true){String key=string();eat(':');result.put(key,value());char c=peek();if(c=='}'){pos++;return result;}eat(',');}}
        List<Object> array(){eat('[');List<Object> r=new ArrayList<>();if(peek()==']'){pos++;return r;}while(true){r.add(value());char c=peek();if(c==']'){pos++;return r;}eat(',');}}
    }
}
